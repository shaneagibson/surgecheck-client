cordova.define("com.jsmobile.plugins.sms.sms", function(require, exports, module) { var smsExport = {};

smsExport.sendMessage = function(textMessage, successCallback, errorCallback) {
    cordova.exec(successCallback, errorCallback, "Sms", "sendMessage", ['', textMessage]);
};

module.exports = smsExport;

});
