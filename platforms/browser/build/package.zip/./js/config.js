define(function(require){

  var exports = {
    google: {
      project_number: 830376253222
    },
    pushapps: {
      app_token: 'e6d5f5bd-5032-4172-be19-d7b41d67f1ef'
    },
    server: {
      scheme: 'http',
      host: '192.168.1.105',
      port: 8090
    }
  };

  return exports;

});