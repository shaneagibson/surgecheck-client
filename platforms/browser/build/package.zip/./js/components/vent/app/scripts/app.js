require.config({

	baseUrl: 'scripts/',
	
	paths: {
		'vent': 'services/event-bus/event-bus',
	}
	
});

require([], function () {
});
