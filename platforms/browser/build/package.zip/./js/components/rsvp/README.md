RSVP.js
=========

Shim repository for [RSVP.js](http://github.com/tildeio/rsvp.js).

Package Managers
----------------

* [Bower](http://bower.io): `rsvp`
