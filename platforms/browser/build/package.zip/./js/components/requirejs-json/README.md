requirejs-json
==============

JSON AMD plugin
